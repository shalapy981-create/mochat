ام او شات (MO Chat) — واتساب بس بالبلوتوث (من غير نت) + أمان
تشغيل: افتح المجلد في Android Studio ← Sync ← شغّله على موبايلين حقيقيين.
الأمان: تشفير طرف-لطرف (ECDH + AES-256-GCM) · مفاتيح مؤقتة لكل اتصال · تحذير لو مفتاح الصاحب اتغير ·
رمز أمان للمقارنة (🔐) · تشفير المحادثات والوسائط على الموبايل بـ Android Keystore ·
قفل بالرقم السري · منع لقطات الشاشة · بدون Backup سحابي.

Made by Eng. Mohamed Shalaby

الحصول على ملف APK:
(أ) Android Studio: Build > Build Bundle(s)/APK(s) > Build APK(s)
(ب) بدون Android Studio: ارفع المجلد على GitHub ← تبويب Actions ← Build APK ← Run workflow ← نزّل MOChat-apk من Artifacts.
