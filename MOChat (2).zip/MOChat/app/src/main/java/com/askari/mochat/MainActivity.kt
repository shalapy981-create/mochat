package com.askari.mochat

import android.Manifest
import android.annotation.SuppressLint
import android.app.AlertDialog
import android.bluetooth.*
import android.content.*
import android.content.pm.PackageManager
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.media.MediaPlayer
import android.media.MediaRecorder
import android.media.RingtoneManager
import android.net.Uri
import android.os.*
import android.text.Editable
import android.text.InputType
import android.text.TextUtils
import android.text.TextWatcher
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.ViewGroup
import android.widget.*
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import java.io.ByteArrayOutputStream
import java.io.File
import java.text.SimpleDateFormat
import java.util.*
import kotlin.concurrent.thread

@SuppressLint("MissingPermission")
class MainActivity : AppCompatActivity(), BtManager.Cb {
    private lateinit var adapter: BluetoothAdapter
    private lateinit var mgr: BtManager
    private lateinit var store: Store
    private lateinit var crypto: Crypto
    private lateinit var prefs: SharedPreferences
    private val green = Color.parseColor("#075E54")
    private val green2 = Color.parseColor("#25D366")
    private val h = Handler(Looper.getMainLooper())
    private var screen = 0            // 0 قايمة المحادثات، 1 شات، 2 شاشات تانية
    private var curConv = ""
    private var convAdapter: BaseAdapter? = null
    private var chatAdapter: BaseAdapter? = null
    private var chatListView: ListView? = null
    private var subView: TextView? = null
    private var titleView: TextView? = null
    private var typingNow = ""
    private val typingClear = Runnable { typingNow = ""; updateSub() }
    private var lastTyping = 0L
    private val pendingInvites = ArrayList<Pair<String, Packet>>()
    private var scanning = false
    private val foundDevices = ArrayList<BluetoothDevice>()
    private val foundNames = ArrayList<String>()
    private var foundAdapter: ArrayAdapter<String>? = null
    private val bmpCache = HashMap<String, Bitmap>()
    private val emojis = listOf("😎", "🦁", "🚀", "🌹", "🎧", "⚡", "🐯", "👑", "🔥", "🦅")
    private val picker = registerForActivityResult(ActivityResultContracts.GetContent()) { u -> if (u != null) sendImage(u) }

    private val receiver = object : BroadcastReceiver() {
        @Suppress("DEPRECATION")
        override fun onReceive(c: Context, i: Intent) {
            if (i.action == BluetoothDevice.ACTION_FOUND && scanning)
                i.getParcelableExtra<BluetoothDevice>(BluetoothDevice.EXTRA_DEVICE)?.let { addFound(it) }
        }
    }

    // ---------- أدوات ----------
    private fun dp(i: Int) = (i * resources.displayMetrics.density).toInt()
    private fun rounded(c: Int, r: Int) = GradientDrawable().apply { setColor(c); cornerRadius = dp(r).toFloat() }
    private fun oval(c: Int) = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(c) }
    private fun col() = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
    private fun tv(t: String, size: Float = 14f, color: Int = Color.parseColor("#1C1C1E"), bold: Boolean = false) =
        TextView(this).apply { text = t; textSize = size; setTextColor(color); if (bold) setTypeface(null, Typeface.BOLD) }
    private fun btn(t: String, color: Int = green, f: () -> Unit) = Button(this).apply {
        text = t; setTextColor(Color.WHITE); background = rounded(color, 14); setOnClickListener { f() } }
    private fun toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_SHORT).show()
    private fun me() = (prefs.getString("emoji", "😎") ?: "😎") + " " + (prefs.getString("name", "") ?: "")
    private fun myStatus() = prefs.getString("status", "") ?: ""
    private fun clean(s: String) = s.replace("|", "").replace(",", "").trim()
    private fun firstChar(s: String) = if (s.isEmpty()) "?" else String(Character.toChars(s.codePointAt(0)))
    private fun fmt(t: Long): String {
        val c = Calendar.getInstance(); val n = Calendar.getInstance(); c.timeInMillis = t
        return if (c.get(Calendar.DAY_OF_YEAR) == n.get(Calendar.DAY_OF_YEAR) && c.get(Calendar.YEAR) == n.get(Calendar.YEAR))
            SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(t)) else SimpleDateFormat("d/M", Locale.getDefault()).format(Date(t))
    }
    private fun preview(m: Msg) = when (m.type) { 1 -> "📷 صورة"; 2 -> "🎙️ رسالة صوتية"; else -> m.text }
    private fun avatar(t: String, s: Int) = TextView(this).apply {
        text = t; textSize = s * 0.45f; setTextColor(Color.WHITE); gravity = Gravity.CENTER; background = oval(Color.parseColor("#6B7C85")) }
    private fun bar(title: String, back: () -> Unit) = LinearLayout(this).apply {
        setBackgroundColor(green); setPadding(dp(12), dp(28), dp(16), dp(12)); gravity = Gravity.CENTER_VERTICAL
        addView(tv("←", 26f, Color.WHITE).apply { setPadding(dp(8), 0, dp(14), 0); setOnClickListener { back() } })
        addView(tv(title, 20f, Color.WHITE, true))
    }
    private val credit = "Made by Eng. Mohamed Shalaby"
    private fun creditView(color: Int = Color.GRAY) = tv(credit, 11f, color).apply { gravity = Gravity.CENTER; setPadding(0, dp(8), 0, dp(8)) }
    private fun showAbout() = AlertDialog.Builder(this).setTitle("MO Chat — ام او شات")
        .setMessage("Version 1.0\n\n$credit\n\nEnd-to-end encrypted Bluetooth messaging. No internet, no servers.")
        .setPositiveButton("OK", null).show()
    private fun newId() = UUID.randomUUID().toString().take(12)

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val ad = (getSystemService(BLUETOOTH_SERVICE) as BluetoothManager).adapter
        if (ad == null) { toast("الجهاز مفيهوش بلوتوث"); finish(); return }
        window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
        adapter = ad; prefs = getSharedPreferences("mo", 0); crypto = Crypto(this); store = Store(this, crypto); mgr = BtManager(adapter, this, crypto)
        val p = (if (Build.VERSION.SDK_INT >= 31)
            arrayOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.BLUETOOTH_ADVERTISE)
        else arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)) + Manifest.permission.RECORD_AUDIO
        requestPermissions(p, 1)
        registerReceiver(receiver, IntentFilter(BluetoothDevice.ACTION_FOUND))
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (screen == 0 || (prefs.getString("name", "") ?: "").isBlank()) finish()
                else { scanning = false; adapter.cancelDiscovery(); chatListScreen() }
            }
        })
        if ((prefs.getString("name", "") ?: "").isBlank()) profileScreen() else { startMgr(); if (crypto.hasPin()) lockScreen() else chatListScreen() }
    }

    override fun onRequestPermissionsResult(rc: Int, perms: Array<out String>, res: IntArray) {
        super.onRequestPermissionsResult(rc, perms, res); startMgr()
    }

    private fun startMgr() {
        if ((prefs.getString("name", "") ?: "").isBlank()) return
        mgr.myName = me(); mgr.myStatus = myStatus(); mgr.start()
    }

    // ---------- البروفايل ----------
    private fun profileScreen() {
        screen = 2
        val root = col().apply { setPadding(dp(24), dp(40), dp(24), dp(24)); setBackgroundColor(Color.parseColor("#F4F7FB")) }
        root.addView(ImageView(this).apply { setImageResource(R.drawable.ic_logo) }, LinearLayout.LayoutParams(dp(80), dp(80)))
        root.addView(tv("بروفايلك", 24f, green, true))
        root.addView(tv("ده اللي هيظهر للناس", 13f, Color.GRAY))
        val name = EditText(this).apply { hint = "اسمك"; setText(prefs.getString("name", "")) }
        val st = EditText(this).apply { hint = "حالتك (مثلاً: متاح 🟢)"; setText(prefs.getString("status", "")) }
        var picked = prefs.getString("emoji", "😎") ?: "😎"
        val row = LinearLayout(this)
        val views = emojis.map { e -> TextView(this).apply { text = e; textSize = 30f; setPadding(dp(10), dp(6), dp(10), dp(6)) } }
        fun mark() = views.forEach { it.background = if (it.text == picked) rounded(Color.parseColor("#CFE5FF"), 12) else null }
        views.forEach { v -> v.setOnClickListener { picked = v.text.toString(); mark() }; row.addView(v) }
        mark()
        val pinEt = EditText(this).apply {
            hint = if (crypto.hasPin()) "رقم سري جديد (اتركه فاضي للإبقاء)" else "رقم سري للتطبيق (اختياري، 4-8 أرقام)"
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD }
        root.addView(name); root.addView(st); root.addView(pinEt)
        if (crypto.hasPin()) root.addView(btn("إلغاء القفل بالرقم السري", Color.GRAY) { crypto.clearPin(); toast("اتلغى القفل") })
        root.addView(HorizontalScrollView(this).apply { addView(row) })
        root.addView(btn("حفظ ✔") {
            val n = clean(name.text.toString())
            if (n.isEmpty()) { toast("اكتب اسمك"); return@btn }
            prefs.edit().putString("name", n).putString("status", clean(st.text.toString())).putString("emoji", picked).apply()
            val pn = pinEt.text.toString()
            if (pn.isNotEmpty()) { if (pn.length < 4) { toast("الرقم السري 4 أرقام على الأقل"); return@btn }; crypto.setPin(pn) }
            startMgr(); mgr.myName = me(); mgr.myStatus = myStatus(); chatListScreen()
        }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(20) })
        root.addView(creditView())
        setContentView(root)
    }

    // ---------- قايمة المحادثات ----------
    private fun sorted() = store.convs.sortedByDescending { it.time }

    private fun chatListScreen() {
        screen = 0; curConv = ""; scanning = false
        val root = FrameLayout(this).apply { setBackgroundColor(Color.WHITE) }
        val c = col()
        val bar = LinearLayout(this).apply { setBackgroundColor(green); setPadding(dp(16), dp(28), dp(16), dp(14)); gravity = Gravity.CENTER_VERTICAL }
        bar.addView(ImageView(this).apply { setImageResource(R.drawable.ic_logo); setOnClickListener { showAbout() } }, LinearLayout.LayoutParams(dp(36), dp(36)))
        bar.addView(tv("  MO Chat", 22f, Color.WHITE, true), LinearLayout.LayoutParams(0, -2, 1f))
        bar.addView(tv("⚙", 24f, Color.WHITE).apply { setOnClickListener { profileScreen() } })
        c.addView(bar)
        convAdapter = ConvAdapter()
        val empty = tv("مفيش محادثات لسه\nاضغط ＋ عشان تبدأ", 16f, Color.GRAY).apply { gravity = Gravity.CENTER; setPadding(dp(20), dp(60), dp(20), 0) }
        c.addView(empty)
        c.addView(ListView(this).apply {
            adapter = convAdapter; emptyView = empty
            setOnItemClickListener { _, _, i, _ -> openChat(sorted()[i].id) }
            setOnItemLongClickListener { _, _, i, _ ->
                val cv = sorted()[i]
                AlertDialog.Builder(this@MainActivity).setMessage("مسح محادثة ${cv.name}؟")
                    .setPositiveButton("مسح") { _, _ -> store.delete(cv.id); refreshList() }.setNegativeButton("لا", null).show(); true
            }
        }, LinearLayout.LayoutParams(-1, 0, 1f))
        c.addView(creditView())
        root.addView(c, FrameLayout.LayoutParams(-1, -1))
        root.addView(tv("＋", 30f, Color.WHITE).apply { gravity = Gravity.CENTER; background = oval(green2)
            setOnClickListener {
                AlertDialog.Builder(this@MainActivity).setItems(arrayOf("💬 محادثة جديدة", "👥 مجموعة جديدة", "📡 خلي جهازي ظاهر للناس")) { _, w ->
                    when (w) {
                        0 -> pickScreen(); 1 -> groupScreen()
                        else -> startActivity(Intent(BluetoothAdapter.ACTION_REQUEST_DISCOVERABLE).putExtra(BluetoothAdapter.EXTRA_DISCOVERABLE_DURATION, 300))
                    }
                }.show()
            } }, FrameLayout.LayoutParams(dp(60), dp(60), Gravity.BOTTOM or Gravity.RIGHT).apply { setMargins(0, 0, dp(20), dp(24)) })
        setContentView(root)
    }

    inner class ConvAdapter : BaseAdapter() {
        override fun getCount() = store.convs.size
        override fun getItem(p: Int) = sorted()[p]
        override fun getItemId(p: Int) = p.toLong()
        override fun getView(pos: Int, cv: View?, parent: ViewGroup): View {
            val c = getItem(pos)
            val row = LinearLayout(this@MainActivity).apply { setPadding(dp(14), dp(10), dp(14), dp(10)); gravity = Gravity.CENTER_VERTICAL }
            row.addView(avatar(if (c.isGroup) "👥" else firstChar(c.name), 48), LinearLayout.LayoutParams(dp(48), dp(48)))
            val mid = col().apply { setPadding(dp(12), 0, dp(12), 0) }
            mid.addView(tv((if (!c.isGroup && mgr.isUp(c.id)) "🟢 " else "") + c.name, 16f, bold = true))
            mid.addView(tv(c.last, 13f, Color.GRAY).apply { maxLines = 1; ellipsize = TextUtils.TruncateAt.END })
            row.addView(mid, LinearLayout.LayoutParams(0, -2, 1f))
            val right = col().apply { gravity = Gravity.END }
            right.addView(tv(if (c.time > 0) fmt(c.time) else "", 11f, Color.GRAY))
            if (c.unread > 0) right.addView(tv(c.unread.toString(), 11f, Color.WHITE, true).apply { background = oval(green2); setPadding(dp(7), dp(2), dp(7), dp(2)) })
            row.addView(right)
            return row
        }
    }

    private fun refreshList() { convAdapter?.notifyDataSetChanged() }

    // ---------- اختيار جهاز / مجموعة ----------
    private fun addFound(d: BluetoothDevice) {
        if (foundDevices.any { it.address == d.address }) return
        foundDevices.add(d); foundNames.add("${d.name ?: "جهاز مجهول"}\n${d.address}"); foundAdapter?.notifyDataSetChanged()
    }

    private fun pickScreen() {
        if (!adapter.isEnabled) { toast("شغّل البلوتوث الأول"); return }
        screen = 2; scanning = true; foundDevices.clear(); foundNames.clear()
        val root = col().apply { setBackgroundColor(Color.WHITE) }
        root.addView(bar("محادثة جديدة") { scanning = false; adapter.cancelDiscovery(); chatListScreen() })
        root.addView(tv("الجهاز التاني لازم يكون فاتح التطبيق وبلوتوث شغال. أول مرة هيطلب اقتران (Pair).", 12f, Color.GRAY).apply { setPadding(dp(16), dp(10), dp(16), dp(10)) })
        foundAdapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, foundNames)
        root.addView(ListView(this).apply {
            adapter = foundAdapter
            setOnItemClickListener { _, _, i, _ ->
                val d = foundDevices[i]; scanning = false; adapter.cancelDiscovery()
                if (store.conv(d.address) == null) { store.convs.add(Conv(d.address, d.name ?: d.address, false)); store.saveConvs() }
                openChat(d.address)
            }
        }, LinearLayout.LayoutParams(-1, 0, 1f))
        adapter.bondedDevices.forEach { addFound(it) }
        adapter.cancelDiscovery(); adapter.startDiscovery()
        setContentView(root)
    }

    private fun groupScreen() {
        val contacts = store.convs.filter { !it.isGroup }
        if (contacts.isEmpty()) { toast("ابدأ محادثة مع حد الأول وبعدين اعمل مجموعة"); return }
        screen = 2
        val root = col().apply { setBackgroundColor(Color.WHITE) }
        root.addView(bar("مجموعة جديدة") { chatListScreen() })
        val name = EditText(this).apply { hint = "اسم المجموعة" }
        root.addView(name, LinearLayout.LayoutParams(-1, -2).apply { setMargins(dp(16), dp(8), dp(16), 0) })
        root.addView(tv("اختار الأعضاء:", 13f, Color.GRAY).apply { setPadding(dp(16), dp(8), dp(16), 0) })
        val lv = ListView(this).apply {
            choiceMode = ListView.CHOICE_MODE_MULTIPLE
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_list_item_multiple_choice, contacts.map { it.name })
        }
        root.addView(lv, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(btn("إنشاء المجموعة ✔", green2) {
            val sel = contacts.filterIndexed { i, _ -> lv.isItemChecked(i) }
            val n = clean(name.text.toString())
            if (n.isEmpty() || sel.isEmpty()) { toast("اكتب اسم واختار عضو على الأقل"); return@btn }
            val gid = newId(); val ids = sel.map { it.id }
            store.convs.add(Conv(gid, n, true, ids))
            store.add(Msg(newId(), gid, "", false, 3, "تم إنشاء المجموعة", "", System.currentTimeMillis(), 0), "تم إنشاء المجموعة")
            ids.forEach { a ->
                val pk = Packet(Packet.INVITE, gid, newId(), me(), n + "\n" + ids.filter { it != a }.joinToString(","))
                if (mgr.isUp(a)) mgr.send(a, pk) else { pendingInvites.add(a to pk); mgr.connect(a) }
            }
            openChat(gid)
        }, LinearLayout.LayoutParams(-1, -2).apply { setMargins(dp(16), dp(8), dp(16), dp(16)) })
        setContentView(root)
    }

    // ---------- الشات ----------
    private fun openChat(id: String) {
        val c = store.conv(id) ?: return
        screen = 1; curConv = id; c.unread = 0; store.saveConvs(); typingNow = ""
        val root = col().apply { setBackgroundColor(Color.parseColor("#ECE5DD")) }
        val bar = LinearLayout(this).apply { setBackgroundColor(green); setPadding(dp(8), dp(28), dp(16), dp(10)); gravity = Gravity.CENTER_VERTICAL }
        bar.addView(tv("←", 26f, Color.WHITE).apply { setPadding(dp(8), 0, dp(10), 0); setOnClickListener { chatListScreen() } })
        bar.addView(avatar(if (c.isGroup) "👥" else firstChar(c.name), 40), LinearLayout.LayoutParams(dp(40), dp(40)))
        val t = col().apply { setPadding(dp(12), 0, 0, 0) }
        titleView = tv(c.name, 17f, Color.WHITE, true); subView = tv("", 12f, Color.parseColor("#CDEBE5"))
        t.addView(titleView); t.addView(subView); bar.addView(t, LinearLayout.LayoutParams(0, -2, 1f))
        bar.addView(tv(if (crypto.verified(id)) "🔒" else "🔐", 22f, Color.WHITE).apply { setPadding(dp(8), 0, dp(8), 0); setOnClickListener { showSecurity(c) } })
        root.addView(bar)
        chatAdapter = MsgAdapter()
        chatListView = ListView(this).apply { adapter = chatAdapter; divider = null; transcriptMode = ListView.TRANSCRIPT_MODE_ALWAYS_SCROLL }
        root.addView(chatListView, LinearLayout.LayoutParams(-1, 0, 1f))
        val input = EditText(this).apply { hint = "اكتب رسالة"; maxLines = 4; background = rounded(Color.WHITE, 22); setPadding(dp(14), dp(8), dp(14), dp(8)) }
        input.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
                val n = System.currentTimeMillis()
                if (!c.isGroup && mgr.isUp(c.id) && n - lastTyping > 2000) { lastTyping = n; mgr.send(c.id, Packet(Packet.TYPING, sender = me())) }
            }
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, d: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, d: Int) {}
        })
        val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(dp(6), dp(6), dp(6), dp(8)) }
        row.addView(tv("📷", 26f).apply { setPadding(dp(8), 0, dp(8), 0); setOnClickListener { skipLock = true; picker.launch("image/*") } })
        row.addView(input, LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(tv("🎙️", 26f).apply {
            setPadding(dp(8), 0, dp(8), 0)
            setOnTouchListener { _, e ->
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> startRec()
                    MotionEvent.ACTION_UP -> stopRec(true)
                    MotionEvent.ACTION_CANCEL -> stopRec(false)
                }
                true
            }
        })
        row.addView(tv("➤", 22f, Color.WHITE).apply { gravity = Gravity.CENTER; background = oval(green)
            setOnClickListener { val x = input.text.toString().trim(); if (x.isNotEmpty()) { sendMsg(0, x); input.setText("") } } },
            LinearLayout.LayoutParams(dp(46), dp(46)))
        root.addView(row)
        setContentView(root)
        updateSub()
        if (c.isGroup) c.members.forEach { mgr.connect(it) } else mgr.connect(id)
    }

    private fun updateSub() {
        val c = store.conv(curConv) ?: return
        subView?.text = when {
            typingNow.isNotEmpty() -> "$typingNow بيكتب..."
            c.isGroup -> "${c.members.size + 1} أعضاء • متصل: ${c.members.count { mgr.isUp(it) }}"
            mgr.isUp(c.id) -> "متصل 🟢"
            else -> "غير متصل — الرسائل هتتبعت أول ما يتصل"
        }
        titleView?.text = c.name
    }

    private fun refreshChat() {
        chatAdapter?.notifyDataSetChanged(); chatListView?.setSelection(maxOf(0, (chatAdapter?.count ?: 1) - 1))
    }

    private fun packetFor(m: Msg, c: Conv): Packet {
        val t = when (m.type) { 1 -> Packet.IMG; 2 -> Packet.AUDIO; else -> Packet.TEXT }
        val d = if (m.file.isNotEmpty()) store.loadMedia(m.file) else null
        return Packet(t, if (c.isGroup) c.id else "", m.id, m.sender, if (m.type == 2) m.dur.toString() else m.text, d, m.time)
    }

    private fun sendMsg(type: Int, text: String = "", data: ByteArray? = null, dur: Int = 0) {
        val c = store.conv(curConv) ?: return
        val id = newId()
        val path = if (data != null) store.saveMedia(id + if (type == 1) ".jpg" else ".m4a", data) else ""
        val m = Msg(id, c.id, me(), true, type, text, path, System.currentTimeMillis(), if (c.isGroup) 1 else 0, dur)
        store.add(m, preview(m))
        val pk = packetFor(m, c)
        if (c.isGroup) c.members.forEach { a -> mgr.send(a, pk) }
        else mgr.send(c.id, pk) { ok ->
            if (ok) { m.status = 1; store.saveMsgs(c.id); refreshChat() } else mgr.connect(c.id)
        }
        refreshChat(); refreshList()
    }

    /** لما صاحبك يتصل: كل رسالة كانت منتظرة (⏳) بتتبعت تلقائياً. */
    private fun flushPending(addr: String) {
        val c = store.conv(addr) ?: return
        if (c.isGroup) return
        store.msgs(addr).filter { it.mine && it.status == 0 && it.type != 3 }.forEach { m ->
            mgr.send(addr, packetFor(m, c)) { ok -> if (ok) { m.status = 1; store.saveMsgs(addr); refreshChat() } }
        }
    }

    private fun sendImage(u: Uri) = thread {
        try {
            val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            contentResolver.openInputStream(u)?.use { BitmapFactory.decodeStream(it, null, o) }
            var s = 1
            while (o.outWidth / s > 1280 || o.outHeight / s > 1280) s *= 2
            val bmp = contentResolver.openInputStream(u)?.use {
                BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = s }) } ?: return@thread
            val bos = ByteArrayOutputStream(); bmp.compress(Bitmap.CompressFormat.JPEG, 65, bos)
            runOnUiThread { sendMsg(1, "", bos.toByteArray()) }
        } catch (e: Exception) { runOnUiThread { toast("تعذر إرسال الصورة") } }
    }

    // ---------- القفل بالرقم السري ----------
    private var locked = false
    private var needLock = false
    private var skipLock = false
    private var lockedUntil = 0L
    private var fails = 0

    private fun lockScreen() {
        locked = true
        val root = col().apply { setPadding(dp(32), dp(120), dp(32), dp(32)); setBackgroundColor(green); gravity = Gravity.CENTER_HORIZONTAL }
        root.addView(ImageView(this).apply { setImageResource(R.drawable.ic_logo) }, LinearLayout.LayoutParams(dp(90), dp(90)))
        root.addView(tv("🔒 ام او شات مقفول", 20f, Color.WHITE, true).apply { setPadding(0, dp(16), 0, dp(16)) })
        val pin = EditText(this).apply {
            hint = "الرقم السري"; inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
            setTextColor(Color.WHITE); setHintTextColor(Color.LTGRAY); gravity = Gravity.CENTER
        }
        root.addView(pin, LinearLayout.LayoutParams(-1, -2))
        root.addView(btn("فتح", green2) {
            if (System.currentTimeMillis() < lockedUntil) { toast("استنى شوية وجرب تاني"); return@btn }
            if (crypto.checkPin(pin.text.toString())) {
                locked = false; fails = 0
                if (screen == 1 && store.conv(curConv) != null) openChat(curConv) else chatListScreen()
            } else {
                pin.setText(""); fails++
                if (fails >= 5) { lockedUntil = System.currentTimeMillis() + 30000; fails = 0; toast("محاولات كتير، استنى 30 ثانية") } else toast("رقم غلط")
            }
        }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(16) })
        root.addView(creditView(Color.parseColor("#CDEBE5")))
        setContentView(root)
    }

    override fun onStop() { super.onStop(); if (skipLock) skipLock = false else if (crypto.hasPin()) needLock = true }
    override fun onStart() { super.onStart(); if (needLock) { needLock = false; lockScreen() } }

    // ---------- رمز الأمان ----------
    private fun showSecurity(c: Conv) {
        val b = AlertDialog.Builder(this)
        if (c.isGroup) { b.setMessage("رسايل المجموعة بتتشفر لكل عضو بمفتاحه. افتح محادثة كل عضو وتحقق من رمز الأمان بتاعه.").setPositiveButton("تمام", null).show(); return }
        val peer = crypto.trusted(c.id)
        if (peer == null) { b.setMessage("لسه مفيش اتصال مشفر مع ${c.name}. اتصل بيه الأول.").setPositiveButton("تمام", null).show(); return }
        val v = crypto.verified(c.id)
        b.setTitle(if (v) "🔒 تم التحقق" else "🔐 رمز الأمان")
            .setMessage("قارن الرمز ده مع اللي ظاهر عند ${c.name} على موبايله. لو متطابق يبقى مفيش حد بيتجسس عليكم:\n\n${crypto.safety(peer)}")
            .setPositiveButton(if (v) "إلغاء التحقق" else "تم التحقق ✔") { _, _ -> crypto.setVerified(c.id, !v); openChat(c.id) }
            .setNegativeButton("إغلاق", null).show()
    }

    override fun keyChanged(addr: String, newPub: ByteArray) {
        val n = store.conv(addr)?.name ?: addr
        AlertDialog.Builder(this).setTitle("⚠️ تحذير أمني")
            .setMessage("مفتاح الأمان بتاع $n اتغير! ممكن يكون غيّر موبايله أو مسح التطبيق، وممكن حد بيحاول ينتحل شخصيته. اتأكد منه بطريقة تانية قبل ما تثق.")
            .setPositiveButton("ثق في المفتاح الجديد") { _, _ -> crypto.trust(addr, newPub); mgr.connect(addr) }
            .setNegativeButton("رفض", null).show()
    }

    // ---------- الاستقبال ----------
    override fun linkChanged(addr: String, up: Boolean) {
        refreshList()
        if (screen == 1) { if (!up && curConv == addr) typingNow = ""; updateSub() }
    }

    override fun packet(addr: String, p: Packet) {
        when (p.type) {
            Packet.HELLO -> {
                store.conv(addr)?.let { if (!it.isGroup && it.name != p.sender) { it.name = p.sender; store.saveConvs() } }
                flushPending(addr)
                pendingInvites.filter { it.first == addr }.forEach { mgr.send(addr, it.second); pendingInvites.remove(it) }
                refreshList(); if (screen == 1) updateSub()
            }
            Packet.TEXT, Packet.IMG, Packet.AUDIO -> receive(addr, p)
            Packet.ACK -> store.msgs(addr).firstOrNull { it.id == p.id }?.let { it.status = 2; store.saveMsgs(addr); refreshChat() }
            Packet.TYPING -> if (screen == 1 && curConv == addr) {
                typingNow = p.sender; updateSub(); h.removeCallbacks(typingClear); h.postDelayed(typingClear, 3000)
            }
            Packet.INVITE -> {
                val others = p.text.substringAfter("\n").split(",").filter { it.isNotBlank() }
                val members = (others + addr).distinct()
                val ex = store.conv(p.conv)
                if (ex == null) {
                    store.convs.add(Conv(p.conv, p.text.substringBefore("\n"), true, members))
                    store.add(Msg(newId(), p.conv, "", false, 3, "${p.sender} ضافك للمجموعة", "", System.currentTimeMillis(), 0), "${p.sender} ضافك للمجموعة")
                    beep()
                } else ex.members = members
                store.saveConvs(); refreshList()
            }
        }
    }

    private fun receive(addr: String, p: Packet) {
        val group = p.conv.isNotEmpty(); val cid = if (group) p.conv else addr
        var c = store.conv(cid)
        if (c == null) { c = Conv(cid, if (group) "مجموعة" else p.sender, group, if (group) listOf(addr) else emptyList()); store.convs.add(c) }
        if (store.msgs(cid).any { it.id == p.id }) return
        if (group && addr !in c.members) c.members = c.members + addr
        val type = when (p.type) { Packet.IMG -> 1; Packet.AUDIO -> 2; else -> 0 }
        val d = p.data
        val path = if (d != null) store.saveMedia(p.id + if (type == 1) ".jpg" else ".m4a", d) else ""
        val m = Msg(p.id, cid, p.sender, false, type, if (type == 2) "" else p.text, path, p.time, 2, if (type == 2) p.text.toIntOrNull() ?: 0 else 0)
        store.add(m, preview(m))
        if (screen == 1 && curConv == cid) refreshChat() else { c.unread++; store.saveConvs() }
        if (!group) mgr.send(addr, Packet(Packet.ACK, "", p.id))
        beep(); refreshList()
    }

    private fun beep() { try { RingtoneManager.getRingtone(this, RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)).play() } catch (_: Exception) {} }

    // ---------- فقاعات الرسائل ----------
    inner class MsgAdapter : BaseAdapter() {
        private fun list() = store.msgs(curConv)
        override fun getCount() = list().size
        override fun getItem(p: Int) = list()[p]
        override fun getItemId(p: Int) = p.toLong()
        override fun getView(pos: Int, cv: View?, parent: ViewGroup): View {
            val m = getItem(pos); val group = store.conv(curConv)?.isGroup == true
            val wrap = LinearLayout(this@MainActivity).apply {
                setPadding(dp(8), dp(3), dp(8), dp(3))
                gravity = if (m.type == 3) Gravity.CENTER_HORIZONTAL else if (m.mine) Gravity.RIGHT else Gravity.LEFT
            }
            if (m.type == 3) {
                wrap.addView(tv(m.text, 12f, Color.GRAY).apply { background = rounded(Color.parseColor("#E1F2FB"), 8); setPadding(dp(10), dp(4), dp(10), dp(4)) })
                return wrap
            }
            val bub = col().apply { setPadding(dp(10), dp(6), dp(10), dp(4)); background = rounded(if (m.mine) Color.parseColor("#DCF8C6") else Color.WHITE, 12) }
            if (!m.mine && group) bub.addView(tv(m.sender, 12f, green, true))
            when (m.type) {
                1 -> {
                    val bmp = bmpCache[m.file] ?: store.loadMedia(m.file)?.let { BitmapFactory.decodeByteArray(it, 0, it.size, BitmapFactory.Options().apply { inSampleSize = 2 }) }?.also { bmpCache[m.file] = it }
                    bub.addView(ImageView(this@MainActivity).apply {
                        if (bmp != null) setImageBitmap(bmp); adjustViewBounds = true; maxWidth = dp(240)
                        setOnClickListener {
                            AlertDialog.Builder(this@MainActivity).setView(ImageView(this@MainActivity).apply {
                                store.loadMedia(m.file)?.let { setImageBitmap(BitmapFactory.decodeByteArray(it, 0, it.size)) }; adjustViewBounds = true }).show()
                        }
                    })
                }
                2 -> bub.addView(tv("▶  رسالة صوتية  %d:%02d".format(m.dur / 60, m.dur % 60), 16f, bold = true).apply {
                    setPadding(dp(4), dp(8), dp(24), dp(8)); setOnClickListener { play(m.file) } })
                else -> bub.addView(tv(m.text, 16f))
            }
            val ticks = if (m.mine && !group) "  " + arrayOf("🕓", "✓", "✓✓")[m.status.coerceIn(0, 2)] else ""
            bub.addView(tv(fmt(m.time) + ticks, 10f, if (m.status == 2) Color.parseColor("#34B7F1") else Color.GRAY).apply { gravity = Gravity.END })
            wrap.addView(bub)
            return wrap
        }
    }

    // ---------- الريكورد ----------
    private var recorder: MediaRecorder? = null
    private var recFile: File? = null
    private var recStart = 0L
    private var player: MediaPlayer? = null
    private val autoStop = Runnable { stopRec(true) }

    private fun startRec() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 2); toast("اسمح بالميكروفون وجرب تاني"); return
        }
        try {
            val f = File(cacheDir, "rec.m4a"); recFile = f
            recorder = (if (Build.VERSION.SDK_INT >= 31) MediaRecorder(this) else MediaRecorder()).apply {
                setAudioSource(MediaRecorder.AudioSource.MIC); setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
                setAudioEncoder(MediaRecorder.AudioEncoder.AAC); setAudioEncodingBitRate(32000); setAudioSamplingRate(16000)
                setOutputFile(f.absolutePath); prepare(); start()
            }
            recStart = System.currentTimeMillis()
            subView?.text = "🔴 بيسجل... ارفع صباعك للإرسال"
            h.postDelayed(autoStop, 60000)
        } catch (e: Exception) { recorder = null; toast("تعذر التسجيل") }
    }

    private fun stopRec(send: Boolean) {
        val r = recorder ?: return
        recorder = null; h.removeCallbacks(autoStop); updateSub()
        val dur = ((System.currentTimeMillis() - recStart) / 1000).toInt()
        try { r.stop() } catch (_: Exception) { r.release(); return }
        r.release()
        val f = recFile ?: return
        if (!send) return
        if (dur < 1) { toast("التسجيل قصير، اضغط واستنى"); return }
        val bytes = f.readBytes(); f.delete(); sendMsg(2, "", bytes, dur)
    }

    private fun play(path: String) {
        try {
            player?.release()
            val b = store.loadMedia(path) ?: return
            val f = File(cacheDir, "play.m4a"); f.writeBytes(b)
            player = MediaPlayer().apply { setDataSource(f.absolutePath); prepare(); start(); setOnCompletionListener { it.release(); f.delete() } }
        } catch (e: Exception) { toast("تعذر تشغيل الصوت") }
    }

    override fun onDestroy() {
        super.onDestroy(); mgr.stop(); player?.release(); recorder?.release()
        try { unregisterReceiver(receiver) } catch (_: Exception) {}
    }
}
