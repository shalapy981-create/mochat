package com.askari.mochat

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

class Conv(val id: String, var name: String, val isGroup: Boolean, var members: List<String> = emptyList(),
           var last: String = "", var time: Long = 0, var unread: Int = 0)

/** type: 0 نص، 1 صورة، 2 صوت، 3 رسالة نظام — status: 0 ⏳ منتظر، 1 ✓ اتبعتت، 2 ✓✓ وصلت */
class Msg(val id: String, val conv: String, val sender: String, val mine: Boolean, val type: Int,
          val text: String, val file: String, val time: Long, var status: Int, val dur: Int = 0)

/** تخزين المحادثات والرسائل على الموبايل (تفضل محفوظة بعد قفل التطبيق). */
class Store(ctx: Context, private val crypto: Crypto) {
    private val p = ctx.getSharedPreferences("mo_store", 0)
    val dir = File(ctx.filesDir, "media").apply { mkdirs() }
    val convs = ArrayList<Conv>()
    private val cache = HashMap<String, ArrayList<Msg>>()

    init {
        val a = JSONArray(rd("convs"))
        for (i in 0 until a.length()) {
            val o = a.getJSONObject(i); val m = o.getJSONArray("mem")
            convs.add(Conv(o.getString("id"), o.getString("n"), o.getBoolean("g"),
                (0 until m.length()).map { m.getString(it) }, o.getString("l"), o.getLong("t"), o.getInt("u")))
        }
    }

    private fun rd(k: String): String {
        val s = p.getString(k, null) ?: return "[]"
        return try { crypto.decStr(s) } catch (_: Exception) { "[]" }
    }
    private fun wr(k: String, v: String) { p.edit().putString(k, crypto.encStr(v)).apply() }
    fun saveMedia(name: String, data: ByteArray): String { val f = File(dir, name); f.writeBytes(crypto.encBytes(data)); return f.absolutePath }
    fun loadMedia(path: String): ByteArray? = try { crypto.decBytes(File(path).readBytes()) } catch (_: Exception) { null }

    fun conv(id: String) = convs.firstOrNull { it.id == id }

    fun saveConvs() {
        val a = JSONArray()
        convs.forEach { c ->
            a.put(JSONObject().put("id", c.id).put("n", c.name).put("g", c.isGroup)
                .put("mem", JSONArray(c.members)).put("l", c.last).put("t", c.time).put("u", c.unread))
        }
        wr("convs", a.toString())
    }

    fun msgs(id: String): ArrayList<Msg> = cache.getOrPut(id) {
        val l = ArrayList<Msg>()
        try {
            val a = JSONArray(rd("m_$id"))
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                l.add(Msg(o.getString("i"), id, o.getString("s"), o.getBoolean("m"), o.getInt("t"), o.getString("x"),
                    o.getString("f"), o.getLong("ti"), o.getInt("st"), o.getInt("d")))
            }
        } catch (_: Exception) {}
        l
    }

    fun saveMsgs(id: String) {
        val a = JSONArray()
        msgs(id).forEach { m ->
            a.put(JSONObject().put("i", m.id).put("s", m.sender).put("m", m.mine).put("t", m.type).put("x", m.text)
                .put("f", m.file).put("ti", m.time).put("st", m.status).put("d", m.dur))
        }
        wr("m_$id", a.toString())
    }

    fun add(m: Msg, preview: String) {
        val l = msgs(m.conv); l.add(m); if (l.size > 300) l.removeAt(0); saveMsgs(m.conv)
        conv(m.conv)?.let { it.last = preview; it.time = m.time }; saveConvs()
    }

    fun delete(id: String) {
        msgs(id).forEach { if (it.file.isNotEmpty()) File(it.file).delete() }
        convs.removeAll { it.id == id }; cache.remove(id); p.edit().remove("m_$id").apply(); saveConvs()
    }
}
