package com.askari.mochat

import android.annotation.SuppressLint
import android.bluetooth.*
import android.os.Handler
import android.os.Looper
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.DataInputStream
import java.io.DataOutputStream
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors
import javax.crypto.SecretKey
import kotlin.concurrent.thread

class Packet(val type: Int, val conv: String = "", val id: String = "", val sender: String = "",
             val text: String = "", val data: ByteArray? = null, val time: Long = System.currentTimeMillis()) {
    companion object {
        const val HELLO = 1; const val TEXT = 2; const val IMG = 3; const val AUDIO = 4
        const val ACK = 5; const val TYPING = 6; const val INVITE = 7
        const val ENC = 8; const val KEYS = 9   // ENC = غلاف مشفر، KEYS = تبادل المفاتيح
        fun read(i: DataInputStream): Packet {
            val t = i.readByte().toInt(); val c = i.readUTF(); val id = i.readUTF(); val s = i.readUTF()
            val x = i.readUTF(); val tm = i.readLong(); val n = i.readInt()
            if (n < 0 || n > 8_000_000) throw java.io.IOException("bad size")
            val d = if (n > 0) ByteArray(n).also { i.readFully(it) } else null
            return Packet(t, c, id, s, x, d, tm)
        }
    }
    fun write(o: DataOutputStream) {
        o.writeByte(type); o.writeUTF(conv); o.writeUTF(id); o.writeUTF(sender); o.writeUTF(text)
        o.writeLong(time); o.writeInt(data?.size ?: 0); data?.let { o.write(it) }; o.flush()
    }
}

/** كل رسالة (حتى نوعها ومين بعتها) بتتشفر جوه غلاف ENC. الاتصال مبيتحسبش "up" إلا بعد التحقق من الهوية. */
@SuppressLint("MissingPermission")
class BtManager(private val adapter: BluetoothAdapter, private val cb: Cb, private val crypto: Crypto) {
    interface Cb {
        fun linkChanged(addr: String, up: Boolean)
        fun packet(addr: String, p: Packet)
        fun keyChanged(addr: String, newPub: ByteArray)
    }
    class Link(val socket: BluetoothSocket, val out: DataOutputStream, val addr: String, val key: SecretKey)

    var myName = ""; var myStatus = ""
    private val uuid: UUID = UUID.fromString("5d1c0a3e-7b21-4f6e-9a55-3c8e1f0b2d44")
    private val main = Handler(Looper.getMainLooper())
    private val io = Executors.newSingleThreadExecutor()
    private val links = ConcurrentHashMap<String, Link>()
    private val connecting = ConcurrentHashMap.newKeySet<String>()
    private var server: BluetoothServerSocket? = null
    @Volatile private var running = false

    fun isUp(a: String) = links.containsKey(a)

    fun start() {
        if (running) return
        running = true
        thread {
            while (running) {
                try {
                    val s = adapter.listenUsingRfcommWithServiceRecord("MOChat", uuid); server = s
                    while (running) attach(s.accept())
                } catch (e: Exception) {
                    try { server?.close() } catch (_: Exception) {}
                    if (running) Thread.sleep(2000)
                }
            }
        }
    }

    private fun attach(s: BluetoothSocket) {
        thread {
            val addr = s.remoteDevice.address
            var link: Link? = null
            try {
                val inp = DataInputStream(s.inputStream); val out = DataOutputStream(s.outputStream)
                val hs = crypto.newHandshake()
                Packet(Packet.KEYS, data = hs.bytes).write(out)
                val theirs = Packet.read(inp)
                val td = theirs.data
                if (theirs.type != Packet.KEYS || td == null) throw SecurityException("no keys")
                val sess = crypto.finish(hs, td)
                val known = crypto.trusted(addr)
                if (known == null) crypto.trust(addr, sess.peerId)
                else if (!known.contentEquals(sess.peerId)) {
                    main.post { cb.keyChanged(addr, sess.peerId) }
                    throw SecurityException("identity key changed")
                }
                val lk = Link(s, out, addr, sess.key)
                if (links.putIfAbsent(addr, lk) != null) return@thread
                link = lk
                main.post { cb.linkChanged(addr, true) }
                write(lk, Packet(Packet.HELLO, sender = myName, text = myStatus))
                while (true) {
                    val outer = Packet.read(inp)
                    val d = outer.data
                    if (outer.type != Packet.ENC || d == null) continue
                    val inner = Packet.read(DataInputStream(ByteArrayInputStream(crypto.open(sess.key, d))))
                    main.post { cb.packet(addr, inner) }
                }
            } catch (_: Exception) {
            } finally {
                try { s.close() } catch (_: Exception) {}
                link?.let { links.remove(addr, it); main.post { cb.linkChanged(addr, false) } }
            }
        }
    }

    fun connect(addr: String) {
        if (links.containsKey(addr) || !connecting.add(addr)) return
        thread {
            try {
                adapter.cancelDiscovery()
                val s = adapter.getRemoteDevice(addr).createRfcommSocketToServiceRecord(uuid)
                s.connect(); attach(s)
            } catch (e: Exception) { main.post { cb.linkChanged(addr, false) } }
            finally { connecting.remove(addr) }
        }
    }

    private fun write(l: Link, p: Packet): Boolean = synchronized(l) {
        try {
            val bo = ByteArrayOutputStream(); p.write(DataOutputStream(bo))
            Packet(Packet.ENC, data = crypto.seal(l.key, bo.toByteArray())).write(l.out); true
        } catch (_: Exception) { false }
    }

    fun send(addr: String, p: Packet, done: ((Boolean) -> Unit)? = null) {
        io.execute {
            val l = links[addr]
            val ok = l != null && write(l, p)
            if (done != null) main.post { done(ok) }
        }
    }

    fun stop() {
        running = false
        try { server?.close() } catch (_: Exception) {}
        links.values.forEach { try { it.socket.close() } catch (_: Exception) {} }
        links.clear()
    }
}
