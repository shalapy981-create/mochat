package com.askari.mochat

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.DataInputStream
import java.io.DataOutputStream
import java.math.BigInteger
import java.security.*
import java.security.spec.PKCS8EncodedKeySpec
import java.security.spec.X509EncodedKeySpec
import javax.crypto.Cipher
import javax.crypto.KeyAgreement
import javax.crypto.KeyGenerator
import javax.crypto.Mac
import javax.crypto.SecretKey
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

class Handshake(val eph: KeyPair, val bytes: ByteArray)
class Session(val key: SecretKey, val peerId: ByteArray)

/**
 * 1) هوية دائمة لكل جهاز (EC P-256) والمفتاح الخاص متشفر بـ Android Keystore.
 * 2) كل اتصال: تبادل مفاتيح مؤقتة (ECDH) موقّعة بالهوية ← تشفير AES-256-GCM (Forward Secrecy).
 * 3) أول مرة بنحفظ مفتاح الصاحب (TOFU)، ولو اتغير بنحذّر ونرفض الاتصال.
 * 4) تشفير كل المحادثات والوسائط على الموبايل نفسه.
 */
class Crypto(ctx: Context) {
    private val p = ctx.getSharedPreferences("mo_keys", 0)
    private val rnd = SecureRandom()
    private val wrap: SecretKey = wrapKey()
    private val idPriv: PrivateKey
    val idPub: ByteArray

    init {
        var priv: PrivateKey? = null; var pub: ByteArray? = null
        val pubS = p.getString("pub", null); val privS = p.getString("priv", null)
        if (pubS != null && privS != null) try {
            pub = Base64.decode(pubS, Base64.NO_WRAP)
            priv = KeyFactory.getInstance("EC").generatePrivate(PKCS8EncodedKeySpec(decBytes(Base64.decode(privS, Base64.NO_WRAP))))
        } catch (_: Exception) { priv = null }
        if (priv == null || pub == null) {
            val kp = ecPair()
            priv = kp.private; pub = kp.public.encoded
            p.edit().putString("pub", Base64.encodeToString(pub, Base64.NO_WRAP))
                .putString("priv", Base64.encodeToString(encBytes(priv.encoded), Base64.NO_WRAP)).apply()
        }
        idPriv = priv!!; idPub = pub!!
    }

    private fun ecPair() = KeyPairGenerator.getInstance("EC").apply { initialize(256) }.generateKeyPair()
    private fun hex(b: ByteArray) = b.joinToString("") { "%02x".format(it) }
    private fun b64(b: ByteArray) = Base64.encodeToString(b, Base64.NO_WRAP)
    private fun unb64(s: String) = Base64.decode(s, Base64.NO_WRAP)

    private fun wrapKey(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (ks.getKey("mo_wrap", null) as? SecretKey)?.let { return it }
        val g = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        g.init(KeyGenParameterSpec.Builder("mo_wrap", KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setKeySize(256).build())
        return g.generateKey()
    }

    // ---- تشفير التخزين المحلي (المفتاح جوه الـ Keystore ومبيخرجش) ----
    fun encBytes(b: ByteArray): ByteArray {
        val c = Cipher.getInstance("AES/GCM/NoPadding"); c.init(Cipher.ENCRYPT_MODE, wrap); return c.iv + c.doFinal(b)
    }
    fun decBytes(b: ByteArray): ByteArray {
        val c = Cipher.getInstance("AES/GCM/NoPadding"); c.init(Cipher.DECRYPT_MODE, wrap, GCMParameterSpec(128, b, 0, 12))
        return c.doFinal(b, 12, b.size - 12)
    }
    fun encStr(s: String) = b64(encBytes(s.toByteArray()))
    fun decStr(s: String) = String(decBytes(unb64(s)))

    // ---- المصافحة وتبادل المفاتيح ----
    fun newHandshake(): Handshake {
        val eph = ecPair(); val ep = eph.public.encoded
        val sig = Signature.getInstance("SHA256withECDSA").apply { initSign(idPriv); update(ep) }.sign()
        val bo = ByteArrayOutputStream(); val o = DataOutputStream(bo)
        for (x in listOf(idPub, ep, sig)) { o.writeInt(x.size); o.write(x) }
        return Handshake(eph, bo.toByteArray())
    }

    fun finish(h: Handshake, theirs: ByteArray): Session {
        val i = DataInputStream(ByteArrayInputStream(theirs))
        fun rd(): ByteArray { val n = i.readInt(); if (n < 0 || n > 512) throw SecurityException("bad"); return ByteArray(n).also { i.readFully(it) } }
        val pid = rd(); val pep = rd(); val sig = rd()
        val kf = KeyFactory.getInstance("EC")
        val ok = Signature.getInstance("SHA256withECDSA").apply { initVerify(kf.generatePublic(X509EncodedKeySpec(pid))); update(pep) }.verify(sig)
        if (!ok) throw SecurityException("bad signature")
        val ka = KeyAgreement.getInstance("ECDH"); ka.init(h.eph.private)
        ka.doPhase(kf.generatePublic(X509EncodedKeySpec(pep)), true)
        val secret = ka.generateSecret()
        val a = h.eph.public.encoded
        val (e1, e2) = if (hex(a) < hex(pep)) a to pep else pep to a
        val (i1, i2) = if (hex(idPub) < hex(pid)) idPub to pid else pid to idPub
        val mac = Mac.getInstance("HmacSHA256"); mac.init(SecretKeySpec(secret, "HmacSHA256"))
        mac.update("MOChat-v1".toByteArray()); mac.update(e1); mac.update(e2); mac.update(i1); mac.update(i2)
        return Session(SecretKeySpec(mac.doFinal(), "AES"), pid)
    }

    fun seal(k: SecretKey, plain: ByteArray): ByteArray {
        val iv = ByteArray(12).also { rnd.nextBytes(it) }
        val c = Cipher.getInstance("AES/GCM/NoPadding"); c.init(Cipher.ENCRYPT_MODE, k, GCMParameterSpec(128, iv))
        return iv + c.doFinal(plain)
    }
    fun open(k: SecretKey, b: ByteArray): ByteArray {
        val c = Cipher.getInstance("AES/GCM/NoPadding"); c.init(Cipher.DECRYPT_MODE, k, GCMParameterSpec(128, b, 0, 12))
        return c.doFinal(b, 12, b.size - 12)
    }

    // ---- الثقة ورمز الأمان ----
    fun trusted(addr: String): ByteArray? = p.getString("t_$addr", null)?.let { unb64(it) }
    fun trust(addr: String, pub: ByteArray) { p.edit().putString("t_$addr", b64(pub)).putBoolean("v_$addr", false).apply() }
    fun verified(addr: String) = p.getBoolean("v_$addr", false)
    fun setVerified(addr: String, v: Boolean) { p.edit().putBoolean("v_$addr", v).apply() }
    fun safety(peer: ByteArray): String {
        val (a, b) = if (hex(idPub) < hex(peer)) idPub to peer else peer to idPub
        val d = MessageDigest.getInstance("SHA-256").digest(a + b)
        return BigInteger(1, d).toString().padStart(60, '0').take(30).chunked(5).joinToString(" ")
    }

    // ---- القفل بالرقم السري ----
    private fun hashPin(pin: String, salt: ByteArray) = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA1")
        .generateSecret(PBEKeySpec(pin.toCharArray(), salt, 100_000, 256)).encoded
    fun hasPin() = p.contains("pin")
    fun clearPin() { p.edit().remove("pin").apply() }
    fun setPin(pin: String) {
        val salt = ByteArray(16).also { rnd.nextBytes(it) }
        p.edit().putString("pin", b64(salt) + ":" + b64(hashPin(pin, salt))).apply()
    }
    fun checkPin(pin: String): Boolean {
        val s = p.getString("pin", null) ?: return true
        val (a, b) = s.split(":")
        return MessageDigest.isEqual(hashPin(pin, unb64(a)), unb64(b))
    }
}
